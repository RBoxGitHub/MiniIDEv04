using MiniIDEv04.Data.Sqlite;
using MiniIDEv04.Services;
using System.Collections.ObjectModel;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace MiniIDEv04.Views
{
    public partial class DropZoneWindow : Window
    {
        private readonly ZipDropService        _dropService = new();
        private readonly SqliteDropLogRepository _dropLog   = new();
        private readonly SqliteAppSettingsRepository _settings = new();

        private List<ZipDropService.DropResult> _results = new();

        public DropZoneWindow()
        {
            InitializeComponent();
            Loaded += async (_, _) => await InitAsync();
        }

        private async Task InitAsync()
        {
            // Load project root from sys_AppSettings
            var root = await _settings.GetValueAsync("ProjectRootPath");
            ProjectRootBox.Text = string.IsNullOrWhiteSpace(root)
                ? @"D:\GrokCryptoTrack\Production-Claude\MiniIDE-WorkFolder\MiniIDEv04"
                : root;

            // Load previous results
            await LoadRecentLogAsync();
        }

        // ── Browse zip ────────────────────────────────────────────────────

        private void BrowseZip_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFileDialog
            {
                Title       = "Select Claude Zip File",
                Filter      = "Zip Files (*.zip)|*.zip",
                Multiselect = false
            };

            // Start in ZipWorkFolder if set
            var workFolder = @"C:\Users\" + Environment.UserName + @"\Downloads";
            if (Directory.Exists(workFolder)) dlg.InitialDirectory = workFolder;

            if (dlg.ShowDialog() == true)
                ZipPathBox.Text = dlg.FileName;
        }

        // ── Browse project root ───────────────────────────────────────────

        private void BrowseRoot_Click(object sender, RoutedEventArgs e)
        {
            var dlg = new OpenFolderDialog
            {
                Title = "Select Project Root Folder"
            };
            if (dlg.ShowDialog() == true)
            {
                ProjectRootBox.Text = dlg.FolderName;
                _ = _settings.SetValueAsync("ProjectRootPath", dlg.FolderName);
            }
        }

        // ── Process zip ───────────────────────────────────────────────────

        private async void ProcessZip_Click(object sender, RoutedEventArgs e)
        {
            var zipPath     = ZipPathBox.Text.Trim();
            var projectRoot = ProjectRootBox.Text.Trim();

            if (string.IsNullOrWhiteSpace(zipPath) || !File.Exists(zipPath))
            { StatusText.Text = "⚠  Select a valid zip file first."; return; }

            if (string.IsNullOrWhiteSpace(projectRoot) || !Directory.Exists(projectRoot))
            { StatusText.Text = "⚠  Project root folder not found."; return; }

            StatusText.Text = "Processing...";

            try
            {
                _results = await Task.Run(() =>
                    _dropService.ProcessZip(zipPath, projectRoot));

                // Bind to grid
                ResultsGrid.ItemsSource = new ObservableCollection<ZipDropService.DropResult>(_results);
                FileCountText.Text      = $"{_results.Count} files  ·  " +
                    $"{_results.Count(r => r.Status == "New")} new  ·  " +
                    $"{_results.Count(r => r.Status == "Updated")} updated";

                // Log to DB
                foreach (var r in _results)
                    await _dropLog.LogDropAsync(
                        Path.GetFileName(zipPath),
                        r.FileName, r.Destination, r.Status);

                StatusText.Text = $"✅  Done — {_results.Count} files deployed  ·  {DateTime.Now:HH:mm:ss}";
            }
            catch (Exception ex)
            {
                StatusText.Text = $"❌  {ex.Message}";
            }
        }

        // ── Load recent log ───────────────────────────────────────────────

        private async Task LoadRecentLogAsync()
        {
            var logs = await _dropLog.GetRecentAsync(100);
            if (logs.Count == 0) return;

            // Convert to DropResult for display
            var display = logs.Select(l => new ZipDropService.DropResult(
                l.ZipFileName, l.FileName, l.Destination, "", l.Status)).ToList();

            ResultsGrid.ItemsSource = new ObservableCollection<ZipDropService.DropResult>(display);
            FileCountText.Text      = $"{logs.Count} recent drop records";
            StatusText.Text         = "Showing recent drop history — select a zip to deploy new files";
        }

        // ── Clear log ─────────────────────────────────────────────────────

        private async void ClearLog_Click(object sender, RoutedEventArgs e)
        {
            var result = MessageBox.Show(
                "Clear all drop log entries?", "Confirm",
                MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result != MessageBoxResult.Yes) return;

            var logs = await _dropLog.GetAllAsync();
            foreach (var log in logs)
                await _dropLog.DeleteAsync(log.Id);

            ResultsGrid.ItemsSource = null;
            FileCountText.Text      = string.Empty;
            StatusText.Text         = "Log cleared.";
        }

        private void Close_Click(object sender, RoutedEventArgs e) => Close();
    }
}
