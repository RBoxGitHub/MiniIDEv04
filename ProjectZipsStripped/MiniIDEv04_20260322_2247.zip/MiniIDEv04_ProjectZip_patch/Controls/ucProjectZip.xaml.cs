using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace CryptoCostBasesEFCore.ucControls
    {
    /// <summary>
    /// Zip-project UserControl.
    /// Walks the project root (the folder that contains the .csproj), adds every
    /// file whose path does not pass through a "bin" or "obj" directory segment,
    /// and writes a timestamped .zip beside the project file.
    ///
    /// Drop this control anywhere in the application — it requires no constructor
    /// arguments and no ViewModel.
    ///
    /// Usage in XAML (after adding the namespace):
    ///     &lt;uc:ucProjectZip /&gt;
    /// </summary>
    public partial class ucProjectZip : UserControl
        {
        // ── Folders to exclude — add more entries here as needed ─────────────
        private static readonly string[] ExcludedFolders =
            {
            "bin",
            "obj",
            ".vs",
            ".git"
            };

        public ucProjectZip()
            {
            InitializeComponent();
            }

        // ── Button handler ────────────────────────────────────────────────────
        private async void ZipButton_Click(object sender, RoutedEventArgs e)
            {
            ZipButton.IsEnabled = false;
            ShowStatus("Finding project root…");

            try
                {
                // ── 1. Locate the project root ────────────────────────────────
                string? projectRoot = FindProjectRoot();

                if (projectRoot is null)
                    {
                    ShowStatus("❌  Could not locate project root (.csproj not found).");
                    return;
                    }

                // ── 2. Build output path  <ProjectRoot>\<FolderName>_yyyyMMdd_HHmm.zip ─
                string folderName  = new DirectoryInfo(projectRoot).Name;
                string timestamp   = DateTime.Now.ToString("yyyyMMdd_HHmm");
                string zipName     = $"{folderName}_{timestamp}.zip";
                string zipPath     = Path.Combine(projectRoot, zipName);

                ShowStatus($"Zipping → {zipName} …");

                // ── 3. Collect files (exclude bin / obj / .vs / .git) ─────────
                var allFiles = Directory.EnumerateFiles(projectRoot, "*.*",
                                    SearchOption.AllDirectories)
                    .Where(f => !IsExcluded(f, projectRoot))
                    .ToList();

                // ── 4. Write the zip on a background thread ───────────────────
                await System.Threading.Tasks.Task.Run(() =>
                    {
                    if (File.Exists(zipPath)) File.Delete(zipPath);

                    using var archive = ZipFile.Open(zipPath, ZipArchiveMode.Create);

                    foreach (var file in allFiles)
                        {
                        // Store with a relative path so the zip is self-contained
                        string entryName = Path.GetRelativePath(projectRoot, file)
                                               .Replace('\\', '/');   // portable separators
                        archive.CreateEntryFromFile(file, entryName,
                                                    CompressionLevel.Optimal);
                        }
                    });

                ShowStatus($"✅  {allFiles.Count} files → {zipName}");
                }
            catch (Exception ex)
                {
                ShowStatus($"❌  {ex.Message}");
                MessageBox.Show($"Zip failed:\n\n{ex.Message}\n\n{ex.StackTrace}",
                                "Zip Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            finally
                {
                ZipButton.IsEnabled = true;
                }
            }

        // ── Helpers ───────────────────────────────────────────────────────────

        /// <summary>
        /// Walk up from the assembly location until we find a folder that
        /// contains a .csproj file.  Works whether the app is run from the
        /// IDE (bin\Debug\net*\) or from the project root itself.
        /// </summary>
        private static string? FindProjectRoot()
            {
            string? dir = AppDomain.CurrentDomain.BaseDirectory;

            while (!string.IsNullOrEmpty(dir))
                {
                if (Directory.GetFiles(dir, "*.csproj").Length > 0)
                    return dir;

                dir = Path.GetDirectoryName(dir);
                }

            return null;
            }

        /// <summary>
        /// Returns true if any segment of the file's path relative to the
        /// project root matches one of the excluded folder names (case-insensitive).
        /// Also skips any .zip files sitting in the project root itself so we
        /// never accidentally nest old backup zips inside a new one.
        /// </summary>
        private static bool IsExcluded(string fullPath, string projectRoot)
            {
            string relative = Path.GetRelativePath(projectRoot, fullPath);

            // Skip previously-generated zip files at the root level
            if (Path.GetExtension(relative).Equals(".zip", StringComparison.OrdinalIgnoreCase)
                && !relative.Contains(Path.DirectorySeparatorChar))
                return true;

            // Split into path segments and check each one
            var segments = relative.Split(Path.DirectorySeparatorChar,
                                          Path.AltDirectorySeparatorChar);

            return segments.Any(seg =>
                ExcludedFolders.Any(ex =>
                    seg.Equals(ex, StringComparison.OrdinalIgnoreCase)));
            }

        /// <summary>Show the status text block with the supplied message.</summary>
        private void ShowStatus(string message)
            {
            StatusText.Text       = message;
            StatusText.Visibility = Visibility.Visible;
            }
        }
    }
