using MiniIDEv04.Controls;
using MiniIDEv04.Data;
using System;
using System.Windows;
using System.Windows.Controls;

namespace MiniIDEv04.Controls
    {
    /// <summary>
    /// Draggable launch panel that hosts ucProjectZip inline.
    /// Registered in sys_Panels as ControlClass = "ProjectZipLauncherControl".
    /// Spawned by PanelControlFactory.Create() → wired in MainWindow.SpawnSinglePanel().
    ///
    /// Implements IDraggablePanel so position changes persist to sys_Panels via
    /// the same Panel_PositionChanged / Panel_DraggingPosition path used by every
    /// other launcher panel.
    /// </summary>
    public partial class ProjectZipLauncherControl : UserControl, IDraggablePanel
        {
        // ── IDraggablePanel ───────────────────────────────────────────────────
        public string PanelKey   { get; private set; } = "ProjectZipLauncher";
        public string PanelTitle { get; private set; } = "🗜  Project Zip";

        public event EventHandler<PanelPositionArgs>? PositionChanged;
        public event EventHandler<PanelPositionArgs>? DraggingPosition;

        // ── Panel-specific click event (wired in MainWindow) ──────────────────
        public event EventHandler? PanelClicked;

        // ── Internal DraggablePanel hosts the visual + title bar ──────────────
        private readonly DraggablePanel _shell;

        public ProjectZipLauncherControl()
            {
            // Build the shell programmatically — same pattern as other launchers
            // that construct their DraggablePanel in code rather than XAML.
            _shell = new DraggablePanel
                {
                Title          = "🗜  Project Zip",
                TitleBarColor  = new System.Windows.Media.SolidColorBrush(
                                     System.Windows.Media.Color.FromRgb(0x1B, 0x5E, 0x20)),
                ShowResizeGrip  = false,
                ShowCloseButton = false,
                Width           = 120,
                Height          = 80,
                PanelBody       = new ucProjectZip()
                };

            // Forward drag events up to MainWindow
            _shell.PositionChanged  += (s, e) => PositionChanged?.Invoke(this, e);
            _shell.DraggingPosition += (s, e) => DraggingPosition?.Invoke(this, e);

            // Wrap in a plain UserControl so the factory returns a UIElement
            Content = _shell;
            }

        // ── Allow MainWindow to stamp the PanelKey from the DB row ───────────
        public void SetPanelKey(string key) => PanelKey = key;
        }
    }
