using MiniIDEv04.Models;
using System.IO;
using System.IO.Compression;
using System.Text.Json;

namespace MiniIDEv04.Services
{
    /// <summary>
    /// Reads a Claude-delivered zip file, parses _manifest.json,
    /// copies each file to the correct project folder, and returns
    /// a list of DropResult rows for display and DB logging.
    /// </summary>
    public class ZipDropService
    {
        public record DropResult(
            string ZipFileName,
            string FileName,
            string Destination,
            string FullDestPath,
            string Status // "New" | "Updated" | "Skipped" | "Error"
        );

        private record ManifestEntry(string file, string destination);

        /// <summary>
        /// Process a zip file against the project root.
        /// Returns one DropResult per file in the manifest.
        /// </summary>
        public List<DropResult> ProcessZip(string zipPath, string projectRoot)
        {
            var results = new List<DropResult>();
            var zipName = Path.GetFileName(zipPath);

            // FIX: Guid.NewGuid():N[..8] is not valid interpolation syntax.
            // Use Guid.NewGuid().ToString("N")[..8] instead.
            var tempDir = Path.Combine(
                Path.GetTempPath(),
                $"MiniIDEv04_Drop_{Guid.NewGuid().ToString("N")[..8]}");

            try
            {
                // Extract to temp
                Directory.CreateDirectory(tempDir);
                ZipFile.ExtractToDirectory(zipPath, tempDir, overwriteFiles: true);

                // Read manifest
                var manifestPath = Path.Combine(tempDir, "_manifest.json");
                if (!File.Exists(manifestPath))
                {
                    // No manifest — try to process all files using folder structure
                    results.AddRange(ProcessWithoutManifest(tempDir, projectRoot, zipName));
                    return results;
                }

                var json = File.ReadAllText(manifestPath);

                // Manifest is an object with a "files" array — deserialize accordingly
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                List<ManifestEntry> entries = new();

                // Support both formats:
                //   Format A: top-level array [ { "file": ..., "destination": ... } ]
                //   Format B: object with "files" array { "files": [ { "source": ..., "target": ... } ] }
                if (root.ValueKind == JsonValueKind.Array)
                {
                    entries = JsonSerializer.Deserialize<List<ManifestEntry>>(json,
                        new JsonSerializerOptions { PropertyNameCaseInsensitive = true })
                        ?? new();
                }
                else if (root.ValueKind == JsonValueKind.Object &&
                         root.TryGetProperty("files", out var filesEl))
                {
                    // Our manifest uses "source" and "target" keys
                    foreach (var f in filesEl.EnumerateArray())
                    {
                        var source = f.TryGetProperty("source", out var s) ? s.GetString() ?? "" : "";
                        var target = f.TryGetProperty("target", out var t) ? t.GetString() ?? "" : "";

                        if (!string.IsNullOrWhiteSpace(source))
                            entries.Add(new ManifestEntry(source, Path.GetDirectoryName(target) ?? "."));
                    }
                }

                if (entries.Count == 0)
                {
                    results.AddRange(ProcessWithoutManifest(tempDir, projectRoot, zipName));
                    return results;
                }

                foreach (var entry in entries)
                {
                    // Source path may use forward or back slashes
                    var normalizedFile = entry.file.Replace('/', Path.DirectorySeparatorChar);
                    var srcFile = Path.Combine(tempDir, normalizedFile);

                    if (!File.Exists(srcFile))
                    {
                        results.Add(new DropResult(zipName, entry.file,
                            entry.destination, "", "Skipped — not found in zip"));
                        continue;
                    }

                    var destDir = string.IsNullOrWhiteSpace(entry.destination) || entry.destination == "."
                        ? projectRoot
                        : Path.Combine(projectRoot, entry.destination.Replace('/', Path.DirectorySeparatorChar).TrimEnd('\\'));

                    Directory.CreateDirectory(destDir);

                    var destFile = Path.Combine(destDir, Path.GetFileName(entry.file));
                    var status   = File.Exists(destFile) ? "Updated" : "New";

                    try
                    {
                        File.Copy(srcFile, destFile, overwrite: true);
                        results.Add(new DropResult(zipName, Path.GetFileName(entry.file),
                            entry.destination, destFile, status));
                    }
                    catch (Exception ex)
                    {
                        results.Add(new DropResult(zipName, Path.GetFileName(entry.file),
                            entry.destination, destFile, $"Error: {ex.Message}"));
                    }
                }
            }
            finally
            {
                // Clean up temp
                try { Directory.Delete(tempDir, recursive: true); } catch { }
            }

            return results;
        }

        /// <summary>
        /// Fallback: no manifest — use folder structure inside zip as destination map.
        /// e.g. Controls\SomeFile.cs → ProjectRoot\Controls\SomeFile.cs
        /// </summary>
        private List<DropResult> ProcessWithoutManifest(
            string tempDir, string projectRoot, string zipName)
        {
            var results = new List<DropResult>();
            var files   = Directory.GetFiles(tempDir, "*.*", SearchOption.AllDirectories);

            foreach (var srcFile in files)
            {
                // Skip the manifest itself and txt checklists
                var name = Path.GetFileName(srcFile);
                if (name == "_manifest.json" || name.EndsWith("DropChecklist.txt"))
                    continue;

                var relative = Path.GetRelativePath(tempDir, srcFile);
                var destFile = Path.Combine(projectRoot, relative);
                var destDir  = Path.GetDirectoryName(destFile)!;
                var status   = File.Exists(destFile) ? "Updated" : "New";

                try
                {
                    Directory.CreateDirectory(destDir);
                    File.Copy(srcFile, destFile, overwrite: true);
                    results.Add(new DropResult(zipName,
                        Path.GetFileName(srcFile),
                        Path.GetDirectoryName(relative) ?? ".",
                        destFile, status));
                }
                catch (Exception ex)
                {
                    results.Add(new DropResult(zipName,
                        Path.GetFileName(srcFile),
                        Path.GetDirectoryName(relative) ?? ".",
                        destFile, $"Error: {ex.Message}"));
                }
            }

            return results;
        }
    }
}
