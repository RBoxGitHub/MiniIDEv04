using MiniIDEv04.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace MiniIDEv04.Views
{
    /// <summary>
    /// Toolbox window — Phase 2 Items 3, 4, 5.
    /// Search box now wired to ToolboxRegistry.ApplyFilter via ProjectViewModel.
    /// Static Expanders replaced by RadPanelBar bound to FilteredGroups in Item 6.
    /// </summary>
    public partial class ToolboxWindow : Window
    {
        private ProjectViewModel? _vm;

        public ToolboxWindow()
        {
            InitializeComponent();
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            if (Owner?.DataContext is ProjectViewModel vm)
            {
                _vm = vm;
                vm.PropertyChanged += Vm_PropertyChanged;

                // Update entry count in footer on load
                UpdateEntryCount();
            }
        }

        private void Vm_PropertyChanged(object? sender,
            System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (_vm is null) return;

            switch (e.PropertyName)
            {
                case nameof(ProjectViewModel.IsScanning):
                    ScanProgressPanel.Visibility = _vm.IsScanning
                        ? Visibility.Visible : Visibility.Collapsed;
                    ScanButton.IsEnabled = !_vm.IsScanning;
                    ScanButton.Content   = _vm.IsScanning ? "⏳ Scanning..." : "🔍 Scan Libraries";
                    break;

                case nameof(ProjectViewModel.ScanStatus):
                    ScanStatusText.Text = _vm.ScanStatus;
                    break;

                case nameof(ProjectViewModel.ScanProgress):
                    ScanProgressBar.Value = _vm.ScanProgress;
                    break;
            }
        }

        private void UpdateEntryCount()
        {
            if (_vm is null) return;
            var count  = _vm.ToolboxRegistry.TotalEntryCount;
            var groups = _vm.ToolboxRegistry.GroupCount;
            FooterText.Text = count > 0
                ? $"{count} controls in {groups} groups  ·  Phase 2 Item 6 — RadPanelBar wiring pending"
                : "Phase 2 Item 6 — RadPanelBar wiring pending";
        }

        // ── Search ────────────────────────────────────────────────────
        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var term = SearchBox.Text;

            // Watermark
            Watermark.Visibility = string.IsNullOrEmpty(term)
                ? Visibility.Visible
                : Visibility.Collapsed;

            // Filter via ToolboxRegistry
            _vm?.FilterToolbox(term);

            // Update count
            UpdateEntryCount();
        }

        // ── Scan button ───────────────────────────────────────────────
        private void ScanButton_Click(object sender, RoutedEventArgs e)
        {
            if (_vm is null) return;
            if (_vm.ScanLibrariesCommand.CanExecute(null))
                _ = _vm.ScanLibrariesCommand.ExecuteAsync(null);
        }

        private void Close_Click(object sender, RoutedEventArgs e)
            => Close();

        protected override void OnClosed(EventArgs e)
        {
            if (_vm is not null)
                _vm.PropertyChanged -= Vm_PropertyChanged;
            base.OnClosed(e);
        }
    }
}
