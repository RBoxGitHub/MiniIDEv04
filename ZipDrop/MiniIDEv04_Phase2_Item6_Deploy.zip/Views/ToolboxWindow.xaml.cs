using MiniIDEv04.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace MiniIDEv04.Views
{
    /// <summary>
    /// Toolbox window — Phase 2 Items 3, 4, 5, 6.
    /// RadPanelBar now bound to ToolboxRegistry.FilteredGroups via ProjectViewModel.
    /// Search box filters live. Scan button triggers LibraryScanner.
    /// </summary>
    public partial class ToolboxWindow : Window
    {
        private ProjectViewModel? _vm;

        public ToolboxWindow()
        {
            InitializeComponent();
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            if (Owner?.DataContext is ProjectViewModel vm)
            {
                _vm = vm;
                vm.PropertyChanged += Vm_PropertyChanged;

                // Bind RadPanelBar to live FilteredGroups collection
                ToolboxPanelBar.ItemsSource = vm.ToolboxGroups;

                UpdateFooter();
            }
        }

        private void Vm_PropertyChanged(object? sender,
            System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (_vm is null) return;

            switch (e.PropertyName)
            {
                case nameof(ProjectViewModel.IsScanning):
                    ScanProgressPanel.Visibility = _vm.IsScanning
                        ? Visibility.Visible : Visibility.Collapsed;
                    ScanButton.IsEnabled = !_vm.IsScanning;
                    ScanButton.Content   = _vm.IsScanning
                        ? "⏳ Scanning..." : "🔍 Scan Libraries";
                    if (!_vm.IsScanning) UpdateFooter();
                    break;

                case nameof(ProjectViewModel.ScanStatus):
                    ScanStatusText.Text = _vm.ScanStatus;
                    break;

                case nameof(ProjectViewModel.ScanProgress):
                    ScanProgressBar.Value = _vm.ScanProgress;
                    break;
            }
        }

        // ── Search ────────────────────────────────────────────────────

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            var term = SearchBox.Text;

            Watermark.Visibility = string.IsNullOrEmpty(term)
                ? Visibility.Visible
                : Visibility.Collapsed;

            _vm?.FilterToolbox(term);
            UpdateFooter();
        }

        // ── Footer ────────────────────────────────────────────────────

        private void UpdateFooter()
        {
            if (_vm is null) return;

            var total  = _vm.ToolboxRegistry.TotalEntryCount;
            var groups = _vm.ToolboxRegistry.GroupCount;
            var term   = SearchBox?.Text ?? string.Empty;

            if (!string.IsNullOrWhiteSpace(term))
            {
                // Show filtered count
                var filtered = _vm.ToolboxGroups.Sum(g => g.Entries.Count);
                FooterText.Text = filtered > 0
                    ? $"🔍 {filtered} match{(filtered == 1 ? "" : "es")} across {_vm.ToolboxGroups.Count} group{(_vm.ToolboxGroups.Count == 1 ? "" : "s")}"
                    : "🔍 No matches";
            }
            else
            {
                FooterText.Text = total > 0
                    ? $"{total} controls in {groups} groups"
                    : "No controls loaded — click Scan Libraries";
            }
        }

        // ── Scan button ───────────────────────────────────────────────

        private void ScanButton_Click(object sender, RoutedEventArgs e)
        {
            if (_vm is null) return;
            if (_vm.ScanLibrariesCommand.CanExecute(null))
                _ = _vm.ScanLibrariesCommand.ExecuteAsync(null);
        }

        private void Close_Click(object sender, RoutedEventArgs e)
            => Close();

        protected override void OnClosed(EventArgs e)
        {
            if (_vm is not null)
                _vm.PropertyChanged -= Vm_PropertyChanged;
            base.OnClosed(e);
        }
    }
}
