using MiniIDEv04.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace MiniIDEv04.Views
{
    /// <summary>
    /// Toolbox window — Phase 2 Items 3 + 4.
    /// Scan button triggers LibraryScanner via ProjectViewModel.ScanLibrariesCommand.
    /// RadPanelBar replaces static Expanders in Phase 2 Item 6.
    /// </summary>
    public partial class ToolboxWindow : Window
    {
        private ProjectViewModel? _vm;

        public ToolboxWindow()
        {
            InitializeComponent();
            Loaded += OnLoaded;
        }

        private void OnLoaded(object sender, RoutedEventArgs e)
        {
            // Walk up to find the ProjectViewModel from the Owner window
            if (Owner?.DataContext is ProjectViewModel vm)
            {
                _vm = vm;

                // Subscribe to scan state changes for progress UI
                vm.PropertyChanged += Vm_PropertyChanged;
            }
        }

        private void Vm_PropertyChanged(object? sender,
            System.ComponentModel.PropertyChangedEventArgs e)
        {
            if (_vm is null) return;

            switch (e.PropertyName)
            {
                case nameof(ProjectViewModel.IsScanning):
                    ScanProgressPanel.Visibility = _vm.IsScanning
                        ? Visibility.Visible : Visibility.Collapsed;
                    ScanButton.IsEnabled = !_vm.IsScanning;
                    ScanButton.Content   = _vm.IsScanning ? "⏳ Scanning..." : "🔍 Scan Libraries";
                    break;

                case nameof(ProjectViewModel.ScanStatus):
                    ScanStatusText.Text = _vm.ScanStatus;
                    break;

                case nameof(ProjectViewModel.ScanProgress):
                    ScanProgressBar.Value = _vm.ScanProgress;
                    break;
            }
        }

        private void ScanButton_Click(object sender, RoutedEventArgs e)
        {
            if (_vm is null) return;
            if (_vm.ScanLibrariesCommand.CanExecute(null))
                _ = _vm.ScanLibrariesCommand.ExecuteAsync(null);
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            Watermark.Visibility = string.IsNullOrEmpty(SearchBox.Text)
                ? Visibility.Visible
                : Visibility.Collapsed;

            // Full filter logic wired in Phase 2 Item 6 via ToolboxRegistry
        }

        private void Close_Click(object sender, RoutedEventArgs e)
            => Close();

        protected override void OnClosed(EventArgs e)
        {
            // Unsubscribe to avoid memory leak
            if (_vm is not null)
                _vm.PropertyChanged -= Vm_PropertyChanged;

            base.OnClosed(e);
        }
    }
}
